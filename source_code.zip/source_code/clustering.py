import pandas as pd
from sklearn_extra.cluster import KMedoids
from sklearn.preprocessing import MinMaxScaler
import numpy as np

#otvorenie normalizovaných profilov
normalized_profiles = pd.read_csv("normalized_training_profiles.csv")

#definovanie počtu klustrov
k = 5

#inicializácia KMedoids
kmedoids = KMedoids(n_clusters=k, metric='euclidean', random_state=42)

#vykonanie klustrovania
kmedoids.fit(normalized_profiles)

#priradenie označení klustrov k datasetu
normalized_profiles['Cluster'] = kmedoids.labels_

#uloženie výsledku klustrov do súboru
normalized_profiles.to_csv('clustered_profiles.csv', index=False)

#vypísanie centier klustrov
print("Cluster Centers (Medoids):")
print(kmedoids.cluster_centers_)
