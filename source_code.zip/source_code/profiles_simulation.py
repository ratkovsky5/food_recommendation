from faker import Faker
import json
import random

#inicializácia premenných
fake = Faker()

allergens = [
    "Peanuts", "Tree Nuts", "Dairy", "Eggs", "Fish", "Shellfish", "Soy",
    "Wheat", "Sesame", "Mustard", "Sulfites", "Corn", "Celery", "Lupin"
]

cuisines = [
    "African", "American", "British", "Cajun", "Caribbean", "Chinese",
    "Eastern European", "European", "French", "German", "Greek", "Indian",
    "Irish", "Italian", "Japanese", "Jewish", "Korean", "Latin American",
    "Mediterranean", "Mexican", "Middle Eastern", "Nordic", "Southern",
    "Spanish", "Thai", "Vietnamese"
]

dietary_restrictions = [
    "Vegan", "Vegetarian", "Pescatarian", "Gluten-Free", "Dairy-Free",
    "Nut-Free", "Low-Carb", "Halal", "Kosher", "Low-Sodium", "Soy-Free",
    "Paleo", "Keto", "Low-FODMAP"
    ]

nutrition_goals = [
    "Weight Loss", "Weight Gain", "Muscle Gain", "High Protein", "Low Fat",
    "Low Carb", "Balanced Diet", "Increased Energy Levels",
    "Improved Digestion", "Heart Health", "Brain Health", "Blood Sugar Control",
    "Anti-Inflammatory"
    ]

dish_types = [
    "Appetizer", "Breakfast", "Brunch", "Lunch", "Dinner", "Dessert", "Snack",
    "Side Dish", "Beverage", "Salad", "Soup", "Main Course", "Finger Food",
    "Bread", "Sauce"
    ]

favorite_ingredients = ["Chicken", "Tomato", "Garlic", "Cheese", "Beef",
                        "Lettuce", "Carrot"]

disliked_ingredients = [
    "Mushrooms", "Olives", "Onions", "Celery", "Cilantro", "Peppers",
    "Tomatoes", "Eggplant", "Brussels sprouts", "Beets", "Asparagus",
    "Broccoli", "Spinach"
]

#Nastavenie pravdepodobností
favorite_prob = 0.5 / len(favorite_ingredients)
disliked_prob = 0.5 / len(disliked_ingredients)

#Funkcia na vygenerovanie profilu
def generate_profile(person_id):
    return {
        "id": person_id,
        "age": fake.random_int(min=18, max=80),
        "favoriteCuisines": list(set(fake.random_choices(cuisines, length=random.randint(0, 3)))),
        "dietaryRestrictions": list(set(fake.random_choices(dietary_restrictions, length=random.randint(0, 2)))),
        "nutritionGoals": list(set(fake.random_choices(nutrition_goals, length=random.randint(0, 2)))),
        "allergens": list(set(fake.random_choices(allergens, length=random.randint(0, 3)))),
        "preferredDishTypes": list(set(fake.random_choices(dish_types, length=random.randint(1, 3)))),
        "cookingTimePreference": fake.random_int(min=15, max=120),
        "favoriteIngredients": list(set(fake.random_choices(
            disliked_ingredients, length=random.choices(population=[0,1,2,3], weights=[0.5, favorite_prob, favorite_prob, favorite_prob], k=1)[0]
        ))),
        "dislikedIngredients": list(set(fake.random_choices(
            disliked_ingredients, length=random.choices(population=[0,1,2], weights=[0.5, disliked_prob, disliked_prob], k=1)[0]
        )))
        }

#vygenerovanie profilov na trénovanie a testovanie
profiles_train = [generate_profile(i+1) for i in range(700)]
profiles_test = [generate_profile(i+1) for i in range(150)]

#zapísanie profilov do súborov
with open("training_profiles.json", "w") as file:
    json.dump(profiles_train, file, indent=4)
    
with open("testing_profiles.json", "w") as file:
    json.dump(profiles_test, file, indent=4)


