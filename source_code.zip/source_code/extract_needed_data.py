import json

#otvorenie súboru všetkých receptov
with open('results.json', 'r') as file:
    all_data = json.load(file)

extracted_recipes = []

#vybratie iba potrebných vlaastností
for recipe in all_data:
    extracted_recipe = {
        "id": recipe.get("id"),
        "title": recipe.get("title"),
        "cookingMinutes": recipe.get("cookingMinutes"),
        "preparationMinutes": recipe.get("preparationMinutes"),
        "healthScore": recipe.get("healthScore"),
        "diets": recipe.get("diets"),
        "glutenFree": recipe.get("glutenFree"),
        "vegan": recipe.get("vegan"),
        "vegetarian": recipe.get("vegetarian"),
        "veryPopular": recipe.get("veryPopular"),
        "dishTypes": recipe.get("dishTypes"),
        "ingredients": [],
    }

    for ingredient in recipe.get("extendedIngredients", []):
        name = ingredient.get("name")
        measures = ingredient.get("measures", {}).get("metric", {})
        amount = measures.get("amount")
        unitLong = measures.get("unitLong")
        
        if name and amount and unitLong:
            extracted_recipe["ingredients"].append({
                "name": name,
                "amount": amount,
                "unitLong": unitLong
            })

    extracted_recipes.append(extracted_recipe)

#zapísanie potrebných vlastností do súboru
with open('extracted_recipes.json', 'w') as output_file:
    json.dump(extracted_recipes, output_file, indent=4)

print("Extraction complete! Saved to extracted_recipes.json.")
