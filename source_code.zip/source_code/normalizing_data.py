from sklearn.preprocessing import MinMaxScaler
import pandas as pd
import json

# Definovanie všetkých možných kategórií
allergens = ["Peanuts", "Tree Nuts", "Dairy", "Eggs", "Fish", "Shellfish", "Soy", "Wheat", "Sesame", "Mustard", "Sulfites", "Corn", "Celery", "Lupin"]
cuisines = ["African", "American", "British", "Cajun", "Caribbean", "Chinese", "Eastern European", "European", "French", "German", "Greek", "Indian", "Irish", "Italian", "Japanese", "Jewish", "Korean", "Latin American", "Mediterranean", "Mexican", "Middle Eastern", "Nordic", "Southern", "Spanish", "Thai", "Vietnamese"]
dietary_restrictions = ["Vegan", "Vegetarian", "Pescatarian", "Gluten-Free", "Dairy-Free", "Nut-Free", "Low-Carb", "Halal", "Kosher", "Low-Sodium", "Soy-Free", "Paleo", "Keto", "Low-FODMAP"]
nutrition_goals = ["Weight Loss", "Weight Gain", "Muscle Gain", "High Protein", "Low Fat", "Low Carb", "Balanced Diet", "Increased Energy Levels", "Improved Digestion", "Heart Health", "Brain Health", "Blood Sugar Control", "Anti-Inflammatory"]
dish_types = ["Appetizer", "Breakfast", "Brunch", "Lunch", "Dinner", "Dessert", "Snack", "Side Dish", "Beverage", "Salad", "Soup", "Main Course", "Finger Food", "Bread", "Sauce"]
favorite_ingredients = ["Chicken", "Tomato", "Garlic", "Cheese", "Beef", "Lettuce", "Carrot"]
disliked_ingredients = ["Mushrooms", "Olives", "Onions", "Celery", "Cilantro", "Peppers", "Tomatoes", "Eggplant", "Brussels sprouts", "Beets", "Asparagus", "Broccoli", "Spinach"]

#Načítanie receptov
with open("extracted_recipes.json", "r") as file:
    recipes_json = json.load(file)

recipes = pd.DataFrame(recipes_json)

# Normalizácia číselných kategórií
numerical_features = ["cookingMinutes", "preparationMinutes", "healthScore"]
scaler = MinMaxScaler()
recipes[numerical_features] = scaler.fit_transform(recipes[numerical_features])

#Extrakcia všetkých ingrediencií z receptov
all_ingredients = set(ingredient["name"] for recipe in recipes_json for ingredient in recipe["ingredients"])
ingredient_columns = {ingredient: [] for ingredient in all_ingredients}

for recipe in recipes_json:
    ingredient_names = {ingredient["name"] for ingredient in recipe["ingredients"]}
    for ingredient in all_ingredients:
        ingredient_columns[ingredient].append(1 if ingredient in ingredient_names else 0)

ingredient_df = pd.DataFrame(ingredient_columns)

#Funkcia na one hot encoding zoznamov
def one_hot_encode_lists(column, possible_categories):
    encoded_df = pd.DataFrame({category: column.apply(lambda x: 1 if category in x else 0) for category in possible_categories})
    return encoded_df

#Uloženie one hot encoding pre každú kategóriu, ktorá je zoznam
encoded_dietary_restrictions = one_hot_encode_lists(recipes['dietaryRestrictions'], dietary_restrictions) if 'dietaryRestrictions' in recipes.columns else pd.DataFrame()
encoded_nutrition_goals = one_hot_encode_lists(recipes['nutritionGoals'], nutrition_goals) if 'nutritionGoals' in recipes.columns else pd.DataFrame()
encoded_allergens = one_hot_encode_lists(recipes['allergens'], allergens) if 'allergens' in recipes.columns else pd.DataFrame()
encoded_favorite_ingredients = one_hot_encode_lists(recipes['favoriteIngredients'], favorite_ingredients) if 'favoriteIngredients' in recipes.columns else pd.DataFrame()
encoded_disliked_ingredients = one_hot_encode_lists(recipes['dislikedIngredients'], disliked_ingredients) if 'dislikedIngredients' in recipes.columns else pd.DataFrame()
encoded_dish_types = one_hot_encode_lists(recipes['dishTypes'], dish_types) if 'dishTypes' in recipes.columns else pd.DataFrame()

#one-hot encoding pre ingrediencie
encoded_ingredients = one_hot_encode_lists(ingredient_df, all_ingredients)

#Spojenie všetkých dát z receptov
encoded_recipes = pd.concat([recipes, encoded_dietary_restrictions, 
                             encoded_nutrition_goals, encoded_allergens, 
                             encoded_dish_types, encoded_favorite_ingredients, 
                             encoded_disliked_ingredients, encoded_ingredients], axis=1)

#Uloženie normalizovaných dát z receptu do súboru
encoded_recipes.to_csv('normalized_recipes.csv', index=False)

#Načíanie profilov
with open("training_profiles.json", "r") as file:
    profiles_json = json.load(file)

profiles = pd.DataFrame(profiles_json)

#Normalizácia číselných hodnôt
numerical_features = ["age", "cookingTimePreference"]
scaler = MinMaxScaler()
profiles[numerical_features] = scaler.fit_transform(profiles[numerical_features])

#Kódovanie vlastností, ktoré sú zoznamy
encoded_dietary_restrictions = one_hot_encode_lists(profiles['dietaryRestrictions'], dietary_restrictions) if 'dietaryRestrictions' in profiles.columns else pd.DataFrame()
encoded_nutrition_goals = one_hot_encode_lists(profiles['nutritionGoals'], nutrition_goals) if 'nutritionGoals' in profiles.columns else pd.DataFrame()
encoded_allergens = one_hot_encode_lists(profiles['allergens'], allergens) if 'allergens' in profiles.columns else pd.DataFrame()
encoded_dish_types = one_hot_encode_lists(profiles['preferredDishTypes'], dish_types) if 'preferredDishTypes' in profiles.columns else pd.DataFrame()
encoded_favorite_ingredients = one_hot_encode_lists(profiles['favoriteIngredients'], favorite_ingredients) if 'favoriteIngredients' in profiles.columns else pd.DataFrame()
encoded_disliked_ingredients = one_hot_encode_lists(profiles['dislikedIngredients'], disliked_ingredients) if 'dislikedIngredients' in profiles.columns else pd.DataFrame()
encoded_cuisines = one_hot_encode_lists(profiles['favoriteCuisines'], cuisines)

#Spojenie všetkých dát z profilov
encoded_profiles = pd.concat([profiles, encoded_cuisines, encoded_dietary_restrictions, 
                              encoded_nutrition_goals, encoded_allergens, 
                              encoded_dish_types, encoded_favorite_ingredients, 
                              encoded_disliked_ingredients], axis=1)

#Uloženie normalizovaných dát z profilov do súboru
encoded_profiles.to_csv('normalized_training_profiles.csv', index=False)
