import requests
import json
import random

existing_ids = set()

#načítanie id receptov, ktoré už boli získane
with open("used_ids.txt", "r") as file:
    string_ids = file.read().split(",")[:-1]
for i in string_ids:
    existing_ids.add(int(i))
    
#množina id receptov, ktoré ešte neboli získané
unique_ids = random.sample(set(range(1, 800001))-existing_ids, 2)
string = ""
for i in unique_ids:
    string += str(i) + ","

#zapísanie id receptov, ktoré sa získajú
with open("used_ids.txt", "a") as file:
    file.write(string)

#získanie receptov pomocou Spoonacular API
api_key = "my_api_key"
url = "https://api.spoonacular.com/recipes/informationBulk"
params = {
    "ids": string,
    "includeNutrition": "false"
}

response = requests.get(url, headers={"x-api-key": api_key}, params=params)

if response.status_code == 200:
    #získanie dát ako JSON súbor
    data = response.json()
    # zapísanie receptov do json súboru
    with open("results.json", "a") as file:
        json.dump(data, file, indent=4)
    
    print("Results saved to results.json")
else:
    print(f"Error: {response.status_code}, {response.text}")

#vypísanie počtu receptov
try:
    with open("results.json", "r") as file:
        data = json.load(file)
        # Extract recipe IDs from the first-level list of dictionaries
        recipe_ids = {recipe["id"] for recipe in data}
        print(len(recipe_ids))
except FileNotFoundError:
    print("JSON file not found.")
except KeyError:
    print("Unexpected JSON structure: 'id' key not found.")


